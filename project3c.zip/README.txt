Paul Rodriguez - 303675125
Jacqueline Lo - 203943529

project 3

Using Paul's project 2 files/set-up.

for this part we decided to change part a of the lucene indexes by concatenating all categories for a specific item and tokenize them in a lucene index, as we were not getting the correct results when we did not tokenize them.

Used EscapeStringUtils class from external library Apache Commons 2. JAR and all files are in lib/.

Paul took care of the search, while Jacqueline took care of XML retrieval function and testing/setting up the web service.