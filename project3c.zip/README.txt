Paul Rodriguez - 303675125
Jacqueline Lo - 203943529

project 3

Using Paul's project 2 files/set-up.

for this part we decided to change part a of the lucene indexes by concatenating all categories for a specific item and tokenize them in a lucene index, as we were not getting the correct results when we did not tokenize them.

we will be using external libraries for escaping characters in XML.
